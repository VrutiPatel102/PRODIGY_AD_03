package com.example.stopwatch;

import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.Locale;

public class MainActivity extends AppCompatActivity {
    private int second = 0;
    private boolean running;
    private boolean wasRunning;
    private long elapsedTime = 0L;
    private long startTime = 0L;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        if (savedInstanceState != null) {
            second = savedInstanceState.getInt("second");
            running = savedInstanceState.getBoolean("running");
            wasRunning = savedInstanceState.getBoolean("wasRunning");
        }
        runTimer();

    }

    private void runTimer() {
        final TextView timeview = findViewById(R.id.time_view);

        final Handler handler = new Handler();
        handler.post(new Runnable() {
            @Override
            public void run() {
                int hours = second / 3600;
                int minutes = (second % 3600) / 60;
                int secs = second % 60;
                int millis = (int) (elapsedTime % 1000);

                String time = String.format(Locale.getDefault(), "%d:%02d:%02d.%03d", hours, minutes, secs, millis);

                timeview.setText(time);

                if (running) {
                    elapsedTime += 10; // increment by 10 milliseconds
                    second = (int) (elapsedTime / 1000);
                }

                handler.postDelayed(this, 10); // update every 10 milliseconds
            }
        });

    }

    @Override
    protected void onPause() {
        super.onPause();
        wasRunning = running;
        running=false;
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (wasRunning){
            running = true;
        }
    }

    public void onClickStart(View view) {
        running = true;
    }

    public void onClickStop(View view) {
        running = false;
    }

    public void onClickStartReset(View view) {
        running = false;
        second = 0;
        elapsedTime = 0;
        TextView timeView = findViewById(R.id.time_view);
        timeView.setText("0:00:00.000");
    }
}